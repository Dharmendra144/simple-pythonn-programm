#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 25 20:09:33 2018

@author: Yuvraj Garg
"""

#This program calculate arc length or a function defined on LINE 21
import numpy as np;
import matplotlib.pyplot as plt;
import math;

dx=.001;
xstart=-math.pi;
xend=math.pi;
no_of_slots=abs(xend-xstart)/dx;
x_axis=np.linspace(xstart,xend,no_of_slots);
y_axis=np.array([]);
for x in x_axis:
    y=math.sin(x);
    y_axis=np.append(y_axis,y);

s=0;
for i in range(len(y_axis)-1):
    dy = y_axis[i + 1] - y_axis[i];
    ds=math.sqrt(dx**2 + dy**2);
    s+=ds;

print("Arc Length of ","function ","in between ",xstart," and ",xend," is ",s)
