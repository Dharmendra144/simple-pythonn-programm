'''
    A very basic encryption program using bitwise operator
'''
file=open('/home/user/Desktop/dump','+r')

s=file.read();
#s = "Data To Be Encrypted"
encryptedData = ""

print("Original Data:", s)

for i in range(len(s)):
    c = ord(s[i])

    b = [0, 0, 0, 0, 0, 0, 0, 0]

    for i in range(8):
#        print("binary of c:", bin(c))
        b[i] = (2 ** i)
#        print("binary of b[i]:",bin(b[i]))

    val = [0, 0, 0, 0, 0, 0, 0, 0]
    for i in range(8):
        val[i] = c & b[i];
#        print("Binary of c:",bin(c))
#        print("Binary Val:",bin(val[i]))

    # flipping

    val[0] = val[0] << 2;
    val[2] = val[2] >> 2;

    val[1] = val[1] << 3;
    val[4] = val[4] >> 3;

    val[3] = val[3] << 3;
    val[6] = val[6] >> 3;

    val[5] = val[5] << 2;
    val[7] = val[7] >> 2;

    val = val[0] | val[1] | val[2] | val[3] | val[4] | val[5] | val[6] | val[7]


    #c = (c & 0b11111100) | b
    c = chr(val)
    encryptedData = encryptedData + (c)

print("Encrypted Data:", encryptedData)

writ=open("/home/rajesh/Desktop/encryptedFile","+w")
writ.write(encryptedData)

'''
    Code for retriving data
'''

retreviedData = ''

for i in range(len(encryptedData)):

    c=ord(encryptedData[i])

    b = [0, 0, 0, 0, 0, 0, 0, 0]

    for i in range(8):
#        print("binary of c:", bin(c))
        b[i] = (2 ** i)
#        print("binary of b[i]:",bin(b[i]))

    val = [0, 0, 0, 0, 0, 0, 0, 0]
    for i in range(8):
        val[i] = c & b[i];
#        print("Binary of c:",bin(c))
#        print("Binary Val:",bin(val[i]))

    # flipping

    val[0] = val[0] << 2;
    val[2] = val[2] >> 2;

    val[1] = val[1] << 3;
    val[4] = val[4] >> 3;

    val[3] = val[3] << 3;
    val[6] = val[6] >> 3;

    val[5] = val[5] << 2;
    val[7] = val[7] >> 2;

    val = val[0] | val[1] | val[2] | val[3] | val[4] | val[5] | val[6] | val[7]


    c = chr(val)
    retreviedData = retreviedData + c;

print("Retrived Data:", retreviedData)
