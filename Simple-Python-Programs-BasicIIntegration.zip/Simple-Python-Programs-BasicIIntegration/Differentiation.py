#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Tue Feb 20 18:47:57 2018

@author: rajesh
"""

#Taylor series
"""
    f(x)=f(x0) + f'(x0)(x-x0) + f''(x0)(x-x0)^2 + f'''(x0)(x-x0)^3 +
         -----   -----------     -------------     -------------        ___________  INFINITY
          0!         1!                 2!              3
"""
import numpy as np;
import math;
import matplotlib.pyplot as plt;

def diffrentiation(x_axis,dx):
    y_diff_1 = np.array([]);
    for x in x_axis:
        y = (math.sin(x + dx) - math.sin(x)) / dx;
        y_diff_1 = np.append(y_diff_1, y);
    return y_diff_1;


dx=0.001
xstart=-0;
xend=2*math.pi;
no_of_slots=int(abs(xend-xstart)/dx)

x_axis=np.linspace(xstart,xend,no_of_slots);
y_axis=np.array([]);

for x in x_axis:
    y=math.sin(x);
    y_axis=np.append(y_axis,y);

y_diff_1=diffrentiation(x_axis,dx)

plt.plot(x_axis,y_axis)
plt.plot(x_axis,y_diff_1)

