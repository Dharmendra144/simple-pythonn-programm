#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Feb  1 20:04:36 2018

@author: Yuvraj
"""

'''
    A very basic program to visualize Integration of function f(x) graphically
    And also find area under that Integrated Function F(x) in between defined limits
    
    d(F(x))
    -------   =  f(x)
     d(x)
     
    #Symbols Used
    
    y = f(x)
    y_integrated = F(x)
    function f(x)'s start(xstart), end(xend), and dx
    function f(x) itself is defined below in for loop at line number 54
    we require a condition for F(x) because integration has infinite solution because of that Constant
        so condition (initial_condition) is required to give a fix visualize Integration of function f(x) graphically
        by default the condition is F(0) = 0
    
    

'''


import numpy as np
import matplotlib.pyplot as plt
import math

#  INPUT's
#  Give Input  xstart, xend, dx, initial_condition
#  function f(x) will be Input later in below for loop

xstart=0;
xend=math.pi;
dx=0.001; #As we decreases the dx, accuracy increases

#   specify initial condition for F(x) at F(0) = ?
#   by default it is F(0) = 0
initial_condition=0   
#   function f(x) itself is defined below in for loop at line number 54

no_of_slots=int(abs(xend-xstart)/dx)
x_axis=np.linspace(xstart,xend,no_of_slots); #its x-axis

y=np.array([]);
for x in x_axis:
    y_next=math.sin(x)  # here you define your function f(x)
                        # here "y_next" works as "f(x)"
                        # f(x)can be define as for:
                        # f(x) = x        #we put y_next = x
                        # f(x) = x**2        #we put y_next = x**2
                        # f(x) = exp(x)        #we put y_next = exp(x)
                        # f(x) = sin(x)   #we put y_next = math.sin(x)              
                        
    y=np.append(y,[y_next]);
    
#Area of small rectangles with height f(x) and width dx
small_rect=y*dx;

y_integrated=np.array([])

sum=initial_condition;  # it's initial_condition for F(x) at F(0)
area=0;

for i in small_rect:
    y_integrated=np.append(y_integrated,[sum]);
    sum=sum+i;
    area+=i
    
plt.plot(x_axis,y)
plt.plot(x_axis,y_integrated)

print 'Area of function in between ',xstart ,' to ',xend,' is:',area
