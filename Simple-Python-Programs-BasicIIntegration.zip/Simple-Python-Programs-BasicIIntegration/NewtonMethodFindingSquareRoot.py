'''
    A basic python program to finding square root
    By using Newton Newton's method (also known as the Newton–Raphson method)
    named after Isaac Newton and Joseph Raphson
    it is a method for finding successively better approximations to the roots of a real-valued function.
    It is one very basic example of a root-finding algorithm

'''


''' n is number whose square root is to be find '''

n=900;

''' Determining Newton guess
    lguess is guess left to n
    rguess is guess right to n
'''

lguess=int(n-1);
rguess=int(n+1);

flag=True;

''' lim is maximum limit to which a loop can run '''

lim=int(10**(len(str(n))/2));

while flag:
    #print("lgueess:",lguess,"   rguess=",rguess)
    i=1;

    while i!=lim and flag and i**2 <= lguess:
        ##print("lguess i:",i)
        if i ** 2 == lguess:
            #print("lguess Terminate with guess=",lguess)
            flag=False;
            sqrtguess=i;
            break;
        i+=1;

    lguess=lguess-1;

    i=1
    while i!=lim and flag and i**2 <= rguess:
        ##print("rguess i:", i)
        if i**2==rguess:
            #print("rguess Terminate with guess=",lguess)
            flag=False;
            sqrtguess = i;
            break;
        i=i+1;

    rguess=rguess+1;

nsqrtguess=sqrtguess
error = nsqrtguess**2 - n

''' precision is the error precision '''
precision=0.00001;


while error > 0.00001 or error <-0.00001:
   fx_k = nsqrtguess ** 2 - n
   dif_fx_k=2*nsqrtguess

   nsqrtguess=nsqrtguess-fx_k/dif_fx_k
   error = nsqrtguess**2 - n

print("square root of:",n," is:",nsqrtguess);

