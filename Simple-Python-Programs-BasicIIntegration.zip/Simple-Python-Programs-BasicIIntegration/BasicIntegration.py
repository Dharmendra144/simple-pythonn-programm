#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Updated on Sun Feb 25 22:03:13 2018
The Update was the use of sympy module 
It provide the feature to give functionality to give our mathematical function (like sine cosine exponential algebric function) argument as a string
But it also reduces the computation speed
@author: Yuvraj Garg
"""

'''
    A very basic program to visualize Integration of function f(x) graphically
    And also find area under that Integrated Function F(x) in between defined limits
    
    d(F(x))
    -------   =  f(x)
     d(x)
     
    #Symbols Used
    
    y = f(x)
    y_integrated = F(x)
    function f(x)'s start(xstart), end(xend), and dx
    function f(x) itself is defined below in for loop at line number 54
    we require a condition for F(x) because integration has infinite solution because of that Constant
        so condition (initial_condition) is required to give a fix visualize Integration of function f(x) graphically
        by default the condition is F(0) = 0
    
    
'''

import numpy as np
import matplotlib.pyplot as plt
import math

# This function here evaluate_formula() is used to provide the feature to the user
# To Send a funtion as a strinf like in funtion integration() we take first argument as a string
# then using funcevaluate_formulation evaluate_formula() we compute th value of the provided function 

#-----------------------------------------------------------------------------------------------

# Here in this function we take 3(compulsory) + 2(not compulsory) argument 
# First is function f(x) whose integration is to be find in the form of a string
                            # here you define your function f(x)
                            # f(x)can be define as for:
                            # f(x) = x
                            # f(x) = x**2
                            # f(x) = exp(x)
                            # f(x) = sin(x)
# Second argument start point of function xstart
# Third argument end point of function xend
# Forth argument (not compulsory) initial_condition for F(x) at x=0 by default F(0)=0
# Fifth argument (not compulsory) dx precision of accurecy as you decreases dx accurecy increases
    #but by decreases dx running time of program also increases

xstart=0;
xend=math.pi;
initial_condition=0;
dx=0.01;

#Function is defined on line number  70

no_of_slots=int(abs(xend-xstart)/dx);
x_axis=np.linspace(xstart,xend,no_of_slots); #its x-axis

y=np.array([]);
for x in x_axis:
    y_next = math.cos(x);
                        # here "y_next" works as "f(x+dx)"
    y=np.append(y,[y_next]);
    
#Area of small rectangles with height f(x) and width dx
small_rect=y*dx;

y_integrated=np.array([])

sum=initial_condition;  # it's initial_condition for F(x) at F(0)
area=0;

for i in small_rect:
    y_integrated=np.append(y_integrated,[sum]);
    sum=sum+i;
    area+=i
    
plt.grid();
plt.plot(x_axis,y)
plt.plot(x_axis,y_integrated)

print 'Area of function in between ',xstart ,' to ',xend,' is:',area
